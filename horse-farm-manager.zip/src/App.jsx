import React, { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";
import {
  Plus,
  Trash2,
  CheckCircle2,
  CalendarDays,
  DollarSign,
  Search,
  Download,
  Upload,
  ClipboardList,
  Horse,
  Truck,
  Wrench,
  Home,
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

// Mobile-first horse farm manager (tasks + horses + expenses)
// Data persists in localStorage (no login needed). Export/Import JSON for backup & sharing.

const STORAGE_KEY = "horse_farm_manager_v1";

const uid = () => Math.random().toString(16).slice(2) + Date.now().toString(16);

const todayISO = () => new Date().toISOString().slice(0, 10);

const money = (n) =>
  new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(Number(n || 0));

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

function startOfMonthISO(d = new Date()) {
  const x = new Date(d);
  x.setDate(1);
  return x.toISOString().slice(0, 10);
}

function addDaysISO(iso, days) {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function dayName(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short" });
}

const TYPES = [
  { key: "feed", label: "Feed & Supplements", icon: Horse },
  { key: "vet", label: "Vet", icon: Wrench },
  { key: "farrier", label: "Farrier", icon: Wrench },
  { key: "boarding", label: "Boarding / Training", icon: Home },
  { key: "supplies", label: "Barn Supplies", icon: Truck },
  { key: "equipment", label: "Equipment / Repairs", icon: Wrench },
  { key: "utilities", label: "Utilities", icon: Home },
  { key: "other", label: "Other", icon: DollarSign },
];

const PRIORITY = [
  { key: "low", label: "Low" },
  { key: "med", label: "Medium" },
  { key: "high", label: "High" },
];

const DEFAULTS = {
  farm: {
    name: "Horse Farm",
    currency: "USD",
  },
  horses: [{ id: uid(), name: "Horse 1", notes: "", active: true }],
  tasks: [
    {
      id: uid(),
      title: "Check water troughs",
      due: todayISO(),
      priority: "med",
      horseId: "",
      area: "Barn",
      notes: "",
      done: false,
      createdAt: Date.now(),
    },
  ],
  expenses: [
    {
      id: uid(),
      date: todayISO(),
      vendor: "",
      category: "feed",
      amount: 0,
      horseId: "",
      memo: "",
      createdAt: Date.now(),
    },
  ],
  vendors: [{ id: uid(), name: "Farrier", phone: "", email: "", notes: "" }],
};

function usePersistedState() {
  const [state, setState] = useState(() => loadState() || DEFAULTS);

  useEffect(() => {
    saveState(state);
  }, [state]);

  return [state, setState];
}

function Pill({ children }) {
  return (
    <span className="inline-flex items-center rounded-full border px-2 py-0.5 text-xs leading-none">
      {children}
    </span>
  );
}

function SectionTitle({ icon: Icon, title, subtitle, right }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div className="flex items-start gap-2">
        <div className="mt-0.5 rounded-2xl border p-2">
          <Icon className="h-4 w-4" />
        </div>
        <div>
          <div className="text-base font-semibold">{title}</div>
          {subtitle ? <div className="text-sm text-neutral-600">{subtitle}</div> : null}
        </div>
      </div>
      {right}
    </div>
  );
}

function Empty({ title, hint, action }) {
  return (
    <div className="rounded-2xl border border-dashed p-5 text-center">
      <div className="text-sm font-medium">{title}</div>
      <div className="mt-1 text-sm text-neutral-600">{hint}</div>
      {action ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}

function FieldRow({ children }) {
  return <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">{children}</div>;
}

function MiniStat({ label, value }) {
  return (
    <div className="rounded-2xl border p-3">
      <div className="text-xs text-neutral-600">{label}</div>
      <div className="mt-1 text-lg font-semibold">{value}</div>
    </div>
  );
}

function ConfirmDelete({ label = "Delete", title, description, onConfirm, disabled }) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="destructive" size="sm" disabled={disabled}>
          <Trash2 className="mr-2 h-4 w-4" />
          {label}
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent className="rounded-2xl">
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm}>Delete</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export default function App() {
  const [state, setState] = usePersistedState();
  const fileRef = useRef(null);

  const horsesById = useMemo(() => {
    const m = new Map();
    for (const h of state.horses) m.set(h.id, h);
    return m;
  }, [state.horses]);

  const totals = useMemo(() => {
    const now = new Date();
    const monthStart = startOfMonthISO(now);
    const y = now.getFullYear();

    let month = 0;
    let year = 0;

    for (const e of state.expenses) {
      const amt = Number(e.amount || 0);
      if (!e.date) continue;
      if (e.date >= monthStart) month += amt;
      if (String(e.date).slice(0, 4) === String(y)) year += amt;
    }

    const openTasks = state.tasks.filter((t) => !t.done).length;
    const dueToday = state.tasks.filter((t) => !t.done && t.due === todayISO()).length;

    return { month, year, openTasks, dueToday, monthStart };
  }, [state.expenses, state.tasks]);

  const expenseByMonth = useMemo(() => {
    const now = new Date();
    const months = [];
    const key = (d) => d.toISOString().slice(0, 7);

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now);
      d.setMonth(d.getMonth() - i);
      months.push({ ym: key(d), total: 0 });
    }
    const idx = new Map(months.map((m, i) => [m.ym, i]));

    for (const e of state.expenses) {
      if (!e.date) continue;
      const ym = String(e.date).slice(0, 7);
      if (idx.has(ym)) months[idx.get(ym)].total += Number(e.amount || 0);
    }
    return months.map((m) => ({ month: m.ym, total: Math.round(m.total * 100) / 100 }));
  }, [state.expenses]);

  const [search, setSearch] = useState("");

  const filteredTasks = useMemo(() => {
    const s = search.trim().toLowerCase();
    const tasks = [...state.tasks].sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      if (a.due !== b.due) return String(a.due || "").localeCompare(String(b.due || ""));
      return (b.createdAt || 0) - (a.createdAt || 0);
    });

    if (!s) return tasks;
    return tasks.filter((t) => {
      const horse = t.horseId ? horsesById.get(t.horseId)?.name || "" : "";
      return (
        (t.title || "").toLowerCase().includes(s) ||
        (t.area || "").toLowerCase().includes(s) ||
        (t.notes || "").toLowerCase().includes(s) ||
        horse.toLowerCase().includes(s)
      );
    });
  }, [state.tasks, search, horsesById]);

  const filteredExpenses = useMemo(() => {
    const s = search.trim().toLowerCase();
    const rows = [...state.expenses].sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));
    if (!s) return rows;
    return rows.filter((e) => {
      const horse = e.horseId ? horsesById.get(e.horseId)?.name || "" : "";
      const cat = TYPES.find((c) => c.key === e.category)?.label || e.category;
      return (
        String(e.vendor || "").toLowerCase().includes(s) ||
        String(e.memo || "").toLowerCase().includes(s) ||
        horse.toLowerCase().includes(s) ||
        String(cat).toLowerCase().includes(s) ||
        String(e.amount || "").toLowerCase().includes(s)
      );
    });
  }, [state.expenses, search, horsesById]);

  const addHorse = (name) => {
    const n = (name || "").trim();
    if (!n) return;
    setState((prev) => ({
      ...prev,
      horses: [{ id: uid(), name: n, notes: "", active: true }, ...prev.horses],
    }));
  };

  const updateHorse = (id, patch) => {
    setState((prev) => ({
      ...prev,
      horses: prev.horses.map((h) => (h.id === id ? { ...h, ...patch } : h)),
    }));
  };

  const deleteHorse = (id) => {
    setState((prev) => ({
      ...prev,
      horses: prev.horses.filter((h) => h.id !== id),
      tasks: prev.tasks.map((t) => (t.horseId === id ? { ...t, horseId: "" } : t)),
      expenses: prev.expenses.map((e) => (e.horseId === id ? { ...e, horseId: "" } : e)),
    }));
  };

  const addTask = (task) => {
    setState((prev) => ({
      ...prev,
      tasks: [{ id: uid(), createdAt: Date.now(), done: false, ...task }, ...prev.tasks],
    }));
  };

  const updateTask = (id, patch) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)),
    }));
  };

  const deleteTask = (id) => {
    setState((prev) => ({ ...prev, tasks: prev.tasks.filter((t) => t.id !== id) }));
  };

  const addExpense = (expense) => {
    setState((prev) => ({
      ...prev,
      expenses: [{ id: uid(), createdAt: Date.now(), ...expense }, ...prev.expenses],
    }));
  };

  const updateExpense = (id, patch) => {
    setState((prev) => ({
      ...prev,
      expenses: prev.expenses.map((e) => (e.id === id ? { ...e, ...patch } : e)),
    }));
  };

  const deleteExpense = (id) => {
    setState((prev) => ({ ...prev, expenses: prev.expenses.filter((e) => e.id !== id) }));
  };

  const addVendor = (vendor) => {
    setState((prev) => ({
      ...prev,
      vendors: [{ id: uid(), ...vendor }, ...prev.vendors],
    }));
  };

  const updateVendor = (id, patch) => {
    setState((prev) => ({
      ...prev,
      vendors: prev.vendors.map((v) => (v.id === id ? { ...v, ...patch } : v)),
    }));
  };

  const deleteVendor = (id) => {
    setState((prev) => ({ ...prev, vendors: prev.vendors.filter((v) => v.id !== id) }));
  };

  const exportJSON = () => {
    const data = JSON.stringify(state, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `horse-farm-manager-${todayISO()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJSON = async (file) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!parsed || typeof parsed !== "object") throw new Error("Invalid file");
      setState({
        farm: parsed.farm || DEFAULTS.farm,
        horses: Array.isArray(parsed.horses) ? parsed.horses : DEFAULTS.horses,
        tasks: Array.isArray(parsed.tasks) ? parsed.tasks : DEFAULTS.tasks,
        expenses: Array.isArray(parsed.expenses) ? parsed.expenses : DEFAULTS.expenses,
        vendors: Array.isArray(parsed.vendors) ? parsed.vendors : DEFAULTS.vendors,
      });
    } catch {
      alert("Could not import that file. Make sure it's a Horse Farm Manager JSON export.");
    }
  };

  const resetAll = () => setState(DEFAULTS);

  const [horseName, setHorseName] = useState("");

  const [taskForm, setTaskForm] = useState({
    title: "",
    due: todayISO(),
    priority: "med",
    horseId: "",
    area: "",
    notes: "",
  });

  const [expenseForm, setExpenseForm] = useState({
    date: todayISO(),
    vendor: "",
    category: "feed",
    amount: "",
    horseId: "",
    memo: "",
  });

  const [vendorForm, setVendorForm] = useState({
    name: "",
    phone: "",
    email: "",
    notes: "",
  });

  const activeHorseOptions = useMemo(() => state.horses.filter((h) => h.active !== false), [state.horses]);

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-md px-4 pb-24 pt-5">
        <div className="sticky top-0 z-10 -mx-4 bg-white/90 px-4 pb-3 pt-2 backdrop-blur">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-xl font-semibold">{state.farm?.name || "Horse Farm"}</div>
              <div className="text-sm text-neutral-600">Tasks • Horses • Expenses</div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={exportJSON} aria-label="Export">
                <Download className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => fileRef.current?.click()} aria-label="Import">
                <Upload className="h-4 w-4" />
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) importJSON(f);
                  e.target.value = "";
                }}
              />
            </div>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3">
            <MiniStat label="Open Tasks" value={totals.openTasks} />
            <MiniStat label="Due Today" value={totals.dueToday} />
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3">
            <MiniStat label="This Month" value={money(totals.month)} />
            <MiniStat label="This Year" value={money(totals.year)} />
          </div>

          <div className="mt-3 flex items-center gap-2">
            <div className="relative w-full">
              <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-neutral-500" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tasks/expenses…" className="pl-9" />
            </div>
          </div>
        </div>

        <Tabs defaultValue="tasks" className="mt-2">
          <TabsList className="grid w-full grid-cols-4 rounded-2xl">
            <TabsTrigger value="tasks" className="rounded-2xl">
              <ClipboardList className="mr-2 h-4 w-4" />
              Tasks
            </TabsTrigger>
            <TabsTrigger value="expenses" className="rounded-2xl">
              <DollarSign className="mr-2 h-4 w-4" />
              Expenses
            </TabsTrigger>
            <TabsTrigger value="horses" className="rounded-2xl">
              <Horse className="mr-2 h-4 w-4" />
              Horses
            </TabsTrigger>
            <TabsTrigger value="reports" className="rounded-2xl">
              <CalendarDays className="mr-2 h-4 w-4" />
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tasks" className="mt-4 space-y-4">
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <SectionTitle icon={Plus} title="Quick Add Task" subtitle="Tap add, it goes straight into your list" />
                <div className="mt-4 space-y-3">
                  <div>
                    <Label>Task</Label>
                    <Input value={taskForm.title} onChange={(e) => setTaskForm((p) => ({ ...p, title: e.target.value }))} placeholder="e.g., Clean stalls, Check fence line" />
                  </div>
                  <FieldRow>
                    <div>
                      <Label>Due Date</Label>
                      <Input type="date" value={taskForm.due} onChange={(e) => setTaskForm((p) => ({ ...p, due: e.target.value }))} />
                    </div>
                    <div>
                      <Label>Priority</Label>
                      <Select value={taskForm.priority} onValueChange={(v) => setTaskForm((p) => ({ ...p, priority: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Priority" />
                        </SelectTrigger>
                        <SelectContent>
                          {PRIORITY.map((p) => (
                            <SelectItem key={p.key} value={p.key}>
                              {p.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </FieldRow>
                  <FieldRow>
                    <div>
                      <Label>Horse (optional)</Label>
                      <Select value={taskForm.horseId} onValueChange={(v) => setTaskForm((p) => ({ ...p, horseId: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="None" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">None</SelectItem>
                          {activeHorseOptions.map((h) => (
                            <SelectItem key={h.id} value={h.id}>
                              {h.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Area</Label>
                      <Input value={taskForm.area} onChange={(e) => setTaskForm((p) => ({ ...p, area: e.target.value }))} placeholder="Barn / Arena / Pasture" />
                    </div>
                  </FieldRow>
                  <div>
                    <Label>Notes</Label>
                    <Textarea value={taskForm.notes} onChange={(e) => setTaskForm((p) => ({ ...p, notes: e.target.value }))} placeholder="Any details…" />
                  </div>
                  <Button
                    className="w-full rounded-2xl"
                    onClick={() => {
                      const title = taskForm.title.trim();
                      if (!title) return;
                      addTask({
                        title,
                        due: taskForm.due || todayISO(),
                        priority: taskForm.priority || "med",
                        horseId: taskForm.horseId || "",
                        area: taskForm.area || "",
                        notes: taskForm.notes || "",
                      });
                      setTaskForm({ title: "", due: todayISO(), priority: "med", horseId: "", area: "", notes: "" });
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Task
                  </Button>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="w-full rounded-2xl"
                      onClick={() => {
                        const base = todayISO();
                        const chores = ["Feed AM", "Feed PM", "Check water", "Pick paddock", "Sweep aisle"];
                        setState((prev) => {
                          const added = [];
                          for (let d = 0; d < 7; d++) {
                            const due = addDaysISO(base, d);
                            for (const c of chores) {
                              added.push({
                                id: uid(),
                                createdAt: Date.now(),
                                done: false,
                                title: c,
                                due,
                                priority: "med",
                                horseId: "",
                                area: "",
                                notes: "",
                              });
                            }
                          }
                          return { ...prev, tasks: [...added, ...prev.tasks] };
                        });
                      }}
                    >
                      <ClipboardList className="mr-2 h-4 w-4" />
                      Add 7-Day Chores
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <SectionTitle icon={ClipboardList} title="Task List" subtitle="Tap a checkbox to complete" right={<Pill>{filteredTasks.length} items</Pill>} />

              {filteredTasks.length === 0 ? (
                <Empty title="No tasks found" hint="Try clearing search or add a new task above." />
              ) : (
                filteredTasks.map((t) => {
                  const horseName = t.horseId ? horsesById.get(t.horseId)?.name : "";
                  const pr = PRIORITY.find((p) => p.key === t.priority)?.label || "";
                  const due = t.due || "";
                  const overdue = !t.done && due && due < todayISO();

                  return (
                    <Card key={t.id} className="rounded-2xl">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="pt-1">
                            <Checkbox checked={!!t.done} onCheckedChange={(v) => updateTask(t.id, { done: !!v })} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <div className={`font-medium ${t.done ? "line-through text-neutral-500" : ""}`}>{t.title}</div>
                                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-neutral-600">
                                  {due ? (
                                    <span className={`inline-flex items-center gap-1 ${overdue ? "text-red-600" : ""}`}>
                                      <CalendarDays className="h-3.5 w-3.5" />
                                      {dayName(due)} {due}
                                    </span>
                                  ) : null}
                                  {t.area ? <Pill>{t.area}</Pill> : null}
                                  {horseName ? <Pill>🐴 {horseName}</Pill> : null}
                                  {pr ? <Badge variant={t.priority === "high" ? "destructive" : t.priority === "med" ? "secondary" : "outline"}>{pr}</Badge> : null}
                                </div>
                              </div>
                              <ConfirmDelete label="" title="Delete task?" description="This removes the task permanently." onConfirm={() => deleteTask(t.id)} />
                            </div>

                            {t.notes ? <div className="mt-3 rounded-2xl border bg-neutral-50 p-3 text-sm">{t.notes}</div> : null}

                            <div className="mt-3 grid grid-cols-2 gap-2">
                              <Button variant="outline" className="rounded-2xl" onClick={() => updateTask(t.id, { due: todayISO() })}>
                                Due Today
                              </Button>
                              <Button variant="outline" className="rounded-2xl" onClick={() => updateTask(t.id, { priority: t.priority === "high" ? "med" : "high" })}>
                                Toggle High
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          <TabsContent value="expenses" className="mt-4 space-y-4">
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <SectionTitle icon={Plus} title="Quick Add Expense" subtitle="Track everything from feed to repairs" />
                <div className="mt-4 space-y-3">
                  <FieldRow>
                    <div>
                      <Label>Date</Label>
                      <Input type="date" value={expenseForm.date} onChange={(e) => setExpenseForm((p) => ({ ...p, date: e.target.value }))} />
                    </div>
                    <div>
                      <Label>Amount</Label>
                      <Input inputMode="decimal" value={expenseForm.amount} onChange={(e) => setExpenseForm((p) => ({ ...p, amount: e.target.value }))} placeholder="0.00" />
                    </div>
                  </FieldRow>
                  <FieldRow>
                    <div>
                      <Label>Category</Label>
                      <Select value={expenseForm.category} onValueChange={(v) => setExpenseForm((p) => ({ ...p, category: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Category" />
                        </SelectTrigger>
                        <SelectContent>
                          {TYPES.map((c) => (
                            <SelectItem key={c.key} value={c.key}>
                              {c.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Horse (optional)</Label>
                      <Select value={expenseForm.horseId} onValueChange={(v) => setExpenseForm((p) => ({ ...p, horseId: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="None" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">None</SelectItem>
                          {activeHorseOptions.map((h) => (
                            <SelectItem key={h.id} value={h.id}>
                              {h.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </FieldRow>
                  <div>
                    <Label>Vendor</Label>
                    <Input value={expenseForm.vendor} onChange={(e) => setExpenseForm((p) => ({ ...p, vendor: e.target.value }))} placeholder="Tractor Supply, Vet clinic, Farrier…" />
                  </div>
                  <div>
                    <Label>Memo</Label>
                    <Textarea value={expenseForm.memo} onChange={(e) => setExpenseForm((p) => ({ ...p, memo: e.target.value }))} placeholder="e.g., Coastal hay 2 bales, Dewormer, Fence charger…" />
                  </div>
                  <Button
                    className="w-full rounded-2xl"
                    onClick={() => {
                      const amt = Number(String(expenseForm.amount || "").replace(/[^0-9.]/g, ""));
                      if (!expenseForm.date) return;
                      if (!isFinite(amt)) return;
                      addExpense({
                        date: expenseForm.date,
                        vendor: expenseForm.vendor || "",
                        category: expenseForm.category || "other",
                        amount: amt,
                        horseId: expenseForm.horseId || "",
                        memo: expenseForm.memo || "",
                      });
                      setExpenseForm({ date: todayISO(), vendor: "", category: "feed", amount: "", horseId: "", memo: "" });
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Expense
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <SectionTitle icon={DollarSign} title="Expense Log" subtitle="Newest first (use search above to filter)" right={<Pill>{filteredExpenses.length} items</Pill>} />

              {filteredExpenses.length === 0 ? (
                <Empty title="No expenses found" hint="Add one above or clear search." />
              ) : (
                filteredExpenses.map((e) => {
                  const horseName = e.horseId ? horsesById.get(e.horseId)?.name : "";
                  const cat = TYPES.find((c) => c.key === e.category)?.label || e.category;

                  return (
                    <Card key={e.id} className="rounded-2xl">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <div className="font-semibold">{money(e.amount)}</div>
                              <Badge variant="secondary">{cat}</Badge>
                              {horseName ? <Pill>🐴 {horseName}</Pill> : null}
                            </div>
                            <div className="mt-1 text-sm text-neutral-600">
                              {e.date || ""}
                              {e.vendor ? ` • ${e.vendor}` : ""}
                            </div>
                            {e.memo ? <div className="mt-3 rounded-2xl border bg-neutral-50 p-3 text-sm">{e.memo}</div> : null}
                          </div>
                          <ConfirmDelete label="" title="Delete expense?" description="This removes the expense permanently." onConfirm={() => deleteExpense(e.id)} />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          <TabsContent value="horses" className="mt-4 space-y-4">
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <SectionTitle icon={Plus} title="Add Horse" subtitle="Keep it simple—name and notes" />
                <div className="mt-4 flex gap-2">
                  <Input value={horseName} onChange={(e) => setHorseName(e.target.value)} placeholder="Horse name" />
                  <Button className="rounded-2xl" onClick={() => { addHorse(horseName); setHorseName(""); }}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <SectionTitle icon={Horse} title="Your Horses" subtitle="Deactivate horses you don’t need right now" right={<Pill>{state.horses.length} total</Pill>} />

              {state.horses.length === 0 ? (
                <Empty title="No horses yet" hint="Add your first horse above." />
              ) : (
                state.horses.map((h) => {
                  const horseTasksOpen = state.tasks.filter((t) => !t.done && t.horseId === h.id).length;
                  const horseSpendMonth = state.expenses
                    .filter((e) => e.horseId === h.id && e.date >= totals.monthStart)
                    .reduce((a, b) => a + Number(b.amount || 0), 0);

                  return (
                    <Card key={h.id} className="rounded-2xl">
                      <CardContent className="p-4">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <div className="text-base font-semibold">{h.name}</div>
                            {h.active === false ? <Badge variant="outline">Inactive</Badge> : <Badge>Active</Badge>}
                          </div>
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <MiniStat label="Open Tasks" value={horseTasksOpen} />
                            <MiniStat label="This Month" value={money(horseSpendMonth)} />
                          </div>

                          <div className="mt-3">
                            <Label>Notes</Label>
                            <Textarea value={h.notes || ""} onChange={(e) => updateHorse(h.id, { notes: e.target.value })} placeholder="Medical, feed plan, training notes…" />
                          </div>

                          <div className="mt-3 flex gap-2">
                            <Button variant="outline" className="w-full rounded-2xl" onClick={() => updateHorse(h.id, { active: h.active === false ? true : false })}>
                              {h.active === false ? "Activate" : "Deactivate"}
                            </Button>
                            <ConfirmDelete title="Delete horse?" description="This removes the horse. Existing tasks/expenses will be unlinked (not deleted)." onConfirm={() => deleteHorse(h.id)} />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>

            <Separator className="my-2" />

            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <SectionTitle icon={Truck} title="Vendors" subtitle="Keep quick contact info" />
                <div className="mt-4 space-y-3">
                  <FieldRow>
                    <div>
                      <Label>Name</Label>
                      <Input value={vendorForm.name} onChange={(e) => setVendorForm((p) => ({ ...p, name: e.target.value }))} />
                    </div>
                    <div>
                      <Label>Phone</Label>
                      <Input value={vendorForm.phone} onChange={(e) => setVendorForm((p) => ({ ...p, phone: e.target.value }))} />
                    </div>
                  </FieldRow>
                  <FieldRow>
                    <div>
                      <Label>Email</Label>
                      <Input value={vendorForm.email} onChange={(e) => setVendorForm((p) => ({ ...p, email: e.target.value }))} />
                    </div>
                    <div>
                      <Label>Notes</Label>
                      <Input value={vendorForm.notes} onChange={(e) => setVendorForm((p) => ({ ...p, notes: e.target.value }))} />
                    </div>
                  </FieldRow>
                  <Button className="w-full rounded-2xl" onClick={() => { const name = vendorForm.name.trim(); if (!name) return; addVendor({ ...vendorForm, name }); setVendorForm({ name: "", phone: "", email: "", notes: "" }); }}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Vendor
                  </Button>

                  <div className="mt-3 space-y-2">
                    {state.vendors.length === 0 ? (
                      <Empty title="No vendors yet" hint="Add your farrier, vet, feed store, etc." />
                    ) : (
                      state.vendors.map((v) => (
                        <div key={v.id} className="rounded-2xl border p-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="font-semibold">{v.name}</div>
                              <div className="mt-1 text-sm text-neutral-600">{[v.phone, v.email].filter(Boolean).join(" • ") || "—"}</div>
                              {v.notes ? <div className="mt-2 text-sm">{v.notes}</div> : null}
                            </div>
                            <ConfirmDelete label="" title="Delete vendor?" description="This removes the vendor entry." onConfirm={() => deleteVendor(v.id)} />
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports" className="mt-4 space-y-4">
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <SectionTitle icon={CalendarDays} title="Spending Trend" subtitle="Last 6 months" />
                <div className="mt-4 h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={expenseByMonth}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v) => money(v)} />
                      <Line type="monotone" dataKey="total" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <SectionTitle icon={Wrench} title="Settings & Backup" subtitle="Keep your data safe" />
                <div className="mt-4 space-y-3">
                  <div>
                    <Label>Farm Name</Label>
                    <Input value={state.farm?.name || ""} onChange={(e) => setState((p) => ({ ...p, farm: { ...(p.farm || {}), name: e.target.value } }))} />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" className="rounded-2xl" onClick={exportJSON}>
                      <Download className="mr-2 h-4 w-4" />
                      Export
                    </Button>
                    <Button variant="outline" className="rounded-2xl" onClick={() => fileRef.current?.click()}>
                      <Upload className="mr-2 h-4 w-4" />
                      Import
                    </Button>
                  </div>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" className="w-full rounded-2xl">
                        Reset All Data
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="rounded-2xl">
                      <AlertDialogHeader>
                        <AlertDialogTitle>Reset everything?</AlertDialogTitle>
                        <AlertDialogDescription>This wipes all horses, tasks, expenses, and vendors from this device.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={resetAll}>Reset</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>

                  <div className="text-xs text-neutral-600">Tip: Add this to your home screen (Safari → Share → “Add to Home Screen”).</div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <div className="fixed bottom-0 left-0 right-0 z-20 border-t bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3 text-sm">
          <div className="flex items-center gap-2 text-neutral-600">
            <CheckCircle2 className="h-4 w-4" />
            Data saves on your phone
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="rounded-2xl" onClick={() => setSearch("")}>
              Clear Search
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
